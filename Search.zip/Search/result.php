﻿<?php
include('db.php');
$id = $_GET['id'];
$q = mysqli_query($conn, "select * from results where id = '$id'");
$result = mysqli_fetch_assoc($q);
?>
<html>
<head>
<link rel="icon" href="fav.ico" type="image/gif" sizes="16x16">
<link rel="icon" href="fav.ico" type="image/gif" sizes="32x32">
<link rel="icon" href="fav.ico" type="image/gif" sizes="48x48">
<title>Search Engine</title>
<link href="style.css" rel="stylesheet">
<link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
</head>
<body>
<form class="search after" action="search.php" method="get">
<input type="search" name="search" value="" placeholder="Search...">
<button type="submit"><i class="fa fa-search" aria-hidden="true"></i></button>
</form>
<div class="result full">
<img src="<?php echo $result['file'];?>" alt="<?php echo $result['title'];?>">
<a><?php echo $result['title'];?></a>
<p><?php echo $result['descrip'];?></p>
<a class="down" href="<?php echo $result['link'];?>">Download</a>
</div>
</body>
</html>