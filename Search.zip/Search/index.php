﻿<?php
include('db.php');
?>
<html>
<head>
<link rel="icon" href="fav.ico" type="image/gif" sizes="16x16">
<link rel="icon" href="fav.ico" type="image/gif" sizes="32x32">
<link rel="icon" href="fav.ico" type="image/gif" sizes="48x48">
<title>Search Engine</title>
<link href="style.css" rel="stylesheet">
<link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
</head>
<body>
<form class="search" action="search.php" method="GET">
<img src="logo.png">
<input type="search" name="search" placeholder="Search...">
<button type="submit"><i class="fa fa-search" aria-hidden="true"></i></button>
</form>
</body>
</html>