<?php
include("db.php");


$title = $_POST['title'];
$descrip = $_POST['descrip'];
$keyw = $_POST['keyw'];
$link = $_POST['link'];
$file = $_POST['fileimg'];

if(isset($_POST['fileimg'])){
    $fileinfo=PATHINFO($_FILES["image"]["name"]);
  $name = $_FILES['file']['name'];
  $target_dir = "upload/";
  $target_file = $target_dir . basename($_FILES["file"]["name"]);

  // Select file type
  $imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));

  // Valid file extensions
  $extensions_arr = array("jpg","jpeg","png","gif");

  // Check extension
  if( in_array($imageFileType,$extensions_arr) ){
 
    // Insert record
    $q = "insert into results(title, descrip, keyw, link, file) values('$title', '$descrip', '$keyw', '$link', '".$name."')";
    $result = mysqli_query($conn, $q);

  
     // Upload file
     move_uploaded_file($_FILES['file']['tmp_name'],$target_dir.$name);

    if($result){header("location: add.html");}else{echo "something went wrong1";}
  }else{echo "something went wrong2";}
 
}else{echo "something went wrong3";}
?>