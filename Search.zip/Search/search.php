﻿<?php
include('db.php');

if (!$_GET){$search = '';}
else{$search = $_GET['search'];}

if(!$search == ""){
    $q = mysqli_query($conn, "select * from results where title = '$search'");
}
else{
    $q = mysqli_query($conn, "select * from results");
}
?>
<html>
<head>
<link rel="icon" href="fav.ico" type="image/gif" sizes="16x16">
<link rel="icon" href="fav.ico" type="image/gif" sizes="32x32">
<link rel="icon" href="fav.ico" type="image/gif" sizes="48x48">
<title>Search Engine</title>
<link href="style.css" rel="stylesheet">
<link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
</head>
<body>
<form class="search after" action="" method="get">
<input type="search" name="search" value="<?php echo $search; ?>" placeholder="Search...">
<button type="submit"><i class="fa fa-search" aria-hidden="true"></i></button>
<?php
while($result = mysqli_fetch_assoc($q)):
?>
<div class="result">
<a href="result.php?id=<?php echo $result['id'];?>"><?php echo $result['title'];?></a>
<p><?php echo $result['descrip'];?></p>
</div>
<?php
endwhile;
if(mysqli_num_rows($q) == 0){
    echo "
    <div class='result'>
    <a>Nothing Found</a>
    <p>Sorry, but nothing matched your search terms. Please try again with some different keywords.</p>
    </div>
    ";
};
?>
</form>
</body>
</html>